#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2019 Baidu.com, Inc. All Rights Reserved
#
################################################################################

import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="genregion",                     # This is the name of the package
    version="0.0.3",                        # The initial release version
    author="Yanyan Li & Ming Zhang",                     # Full name of the author
    description="Region generation using urban road netwok",
    long_description=long_description,      # Long description read from the the readme file
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),    # List of all python modules to be installed
    py_modules=["genregion"],             # Name of the python package
    install_requires=['ordered_set', "shapely"]                     # Install other dependencies if any
)

